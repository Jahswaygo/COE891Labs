var treeMapJson = {"id":"Clover database Mon Feb 10 2025 22:52:03 EST0","name":"","data":{
    "$area":190.0,"$color":100.0,"title":" 190 Elements, 100% Coverage"},
  "children":[{"id":"question3114","name":"question3","data":{"$area":18.0,
        "$color":100.0,"title":"question3 18 Elements, 100% Coverage"},
      "children":[{"id":"Triclass135","name":"Triclass","data":{"$area":
            18.0,"$color":100.0,"path":"question3/Triclass.html#Triclass",
            "title":"Triclass 18 Elements, 100% Coverage"},"children":[]}]},{
      "id":"question10","name":"question1","data":{"$area":172.0,"$color":
        100.0,"title":"question1 172 Elements, 100% Coverage"},"children":[{
          "id":"IMoney114","name":"IMoney","data":{"$area":0.0,"$color":
            -100.0,"path":"question1/IMoney.html#IMoney","title":
            "IMoney 0 Elements,  -  Coverage"},"children":[]},{"id":
          "MoneyBag153","name":"MoneyBag","data":{"$area":125.0,"$color":
            100.0,"path":"question1/MoneyBag.html#MoneyBag","title":
            "MoneyBag 125 Elements, 100% Coverage"},"children":[]},{"id":
          "Money388","name":"Money","data":{"$area":47.0,"$color":100.0,
            "path":"question1/Money.html#Money","title":
            "Money 47 Elements, 100% Coverage"},"children":[]}]}]}
;
processTreeMapJson (treeMapJson);