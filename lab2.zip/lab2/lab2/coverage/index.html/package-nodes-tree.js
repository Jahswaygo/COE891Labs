 

var Packages = {
    nodes: [
                                                                                                                        
                
{
    "id": "question1",
    "text": "question1",
    "package": "question1",
    "url": "question1/pkg-summary.html",
            "coverage": "100%",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
            "li_attr": {"data-is-link": "true"},
        "a_attr": {"href": "question1/pkg-summary.html"},
    "children": [
                    ]
},
                                            
                
{
    "id": "question3",
    "text": "question3",
    "package": "question3",
    "url": "question3/pkg-summary.html",
            "coverage": "100%",
        "icon": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed",
            "li_attr": {"data-is-link": "true"},
        "a_attr": {"href": "question3/pkg-summary.html"},
    "children": [
                    ]
},
                        ],
    settings: {
        "icons": {
            "package": {
                "open": "aui-icon aui-icon-small aui-iconfont-devtools-folder-open",
                "closed": "aui-icon aui-icon-small aui-iconfont-devtools-folder-closed"
            },
            "state": {
                "collapsed": "aui-icon aui-icon-small aui-iconfont-collapsed",
                "expanded": "aui-icon aui-icon-small aui-iconfont-expanded",
                "forRemoval": "hidden aui-iconfont-collapsed aui-iconfont-expanded"
            }
        }
    }
};
